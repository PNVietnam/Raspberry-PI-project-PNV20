<html>
        <form method="GET" action="de41.php">
        <input type="number" name="number" />
        <button type="submit"> Submit </button>
        </form>
</html>

