<html>
	<form method="GET" action="de31.php">
	<input type="password" name="password" />
	<button type="submit"> Submit </button>
	</form>
</html>
