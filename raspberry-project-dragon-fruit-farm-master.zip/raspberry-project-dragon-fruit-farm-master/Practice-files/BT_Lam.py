import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(7,GPIO.OUT)
GPIO.setup(9,GPIO.OUT)
GPIO.setup(18,GPIO.OUT)
GPIO.setup(23,GPIO.OUT)
GPIO.setup(25,GPIO.OUT)

print ("LED on")

GPIO.output(18,GPIO.HIGH)
GPIO.output(23,GPIO.HIGH)
GPIO.output(25,GPIO.HIGH)
GPIO.output(9,GPIO.HIGH)
GPIO.output(7,GPIO.HIGH)
time.sleep(0.5)

print ("LED off")
GPIO.output(18,GPIO.LOW)
GPIO.output(23,GPIO.LOW)
GPIO.output(25,GPIO.LOW)
GPIO.output(9,GPIO.LOW)
GPIO.output(7,GPIO.LOW)
 
count = 0;
while True:
    print ("Led On")
    GPIO.output(18,GPIO.HIGH)
    GPIO.output(23,GPIO.HIGH)
    time.sleep(0.5)
    print ("Led Off")
    GPIO.output(18,GPIO.LOW)
    GPIO.output(23,GPIO.LOW)
    
    print ("Led On")
    GPIO.output(23,GPIO.HIGH)
    GPIO.output(25,GPIO.HIGH)
    time.sleep(0.5)
    print ("Led Off")
    GPIO.output(23,GPIO.LOW)
    GPIO.output(25,GPIO.LOW)
    
    print ("Led On")
    GPIO.output(25,GPIO.HIGH)
    GPIO.output(9,GPIO.HIGH)
    time.sleep(0.5)
    print ("Led Off")
    GPIO.output(25,GPIO.LOW)
    GPIO.output(9,GPIO.LOW)
    
    print ("Led On")
    GPIO.output(9,GPIO.HIGH)
    GPIO.output(7,GPIO.HIGH)
    time.sleep(0.5)
    print ("Led Off")
    GPIO.output(9,GPIO.LOW)
    GPIO.output(7,GPIO.LOW)
    
    
    print ("On All Leds right")
    GPIO.output(18,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(18,GPIO.LOW)
    
    
    GPIO.output(23,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(23,GPIO.LOW)
        
    GPIO.output(25,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(25,GPIO.LOW)
    
    GPIO.output(9,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(9,GPIO.LOW)
    
    GPIO.output(7,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(7,GPIO.LOW)
    
    
    print ("On All Leds left")
    GPIO.output(7,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(7,GPIO.LOW)
    
    GPIO.output(9,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(9,GPIO.LOW)
    
    GPIO.output(25,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(25,GPIO.LOW)
      
    GPIO.output(23,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(23,GPIO.LOW)
    
    GPIO.output(18,GPIO.HIGH)
    time.sleep(0.1)
    GPIO.output(18,GPIO.LOW)
    break

print ("End")
