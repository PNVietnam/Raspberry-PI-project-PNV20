import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
i=0

while True:
    GPIO.setup(18,GPIO.OUT)
    GPIO.setup(23,GPIO.OUT)
    GPIO.setup(25,GPIO.OUT)

    GPIO.output(18,GPIO.HIGH)
    GPIO.output(23,GPIO.HIGH)
    GPIO.output(25,GPIO.HIGH)
    if i == 1:
        GPIO.output(18,GPIO.LOW)
        time.sleep(1)
        GPIO.output(18,GPIO.HIGH)
        i = 2
    elif i == 2:
        GPIO.output(23,GPIO.LOW)
        time.sleep(1)
        GPIO.output(23,GPIO.HIGH)
        i = 3
    elif i ==3:
        GPIO.output(25,GPIO.LOW)
        time.sleep(1)
        GPIO.output(25,GPIO.HIGH)
        i = 4
    elif i ==4:
        GPIO.output(18,GPIO.LOW)
        GPIO.output(23,GPIO.LOW)
        GPIO.output(25,GPIO.LOW)
        time.sleep(1)
        i = 5
    elif i ==5:
        GPIO.output(18,GPIO.HIGH)
        GPIO.output(23,GPIO.HIGH)
        GPIO.output(25,GPIO.HIGH)
        time.sleep(1)
        i = 1
    

