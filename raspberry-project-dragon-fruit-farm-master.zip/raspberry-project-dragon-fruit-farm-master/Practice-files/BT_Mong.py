import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(23,GPIO.OUT)
GPIO.setup(25,GPIO.OUT)
GPIO.setup(9,GPIO.OUT)
i = count = 1
while True:
    print(count)
    count+=1
    if count == 10:
        GPIO.output(23,GPIO.LOW)
        GPIO.output(25,GPIO.LOW)
        GPIO.output(9,GPIO.LOW)
        break
    elif i == 1:
        GPIO.output(25,GPIO.HIGH)
        time.sleep(1)
        i = 2
    elif i == 2:
        GPIO.output(9,GPIO.HIGH)
        GPIO.output(23,GPIO.HIGH)
        time.sleep(1)
        i = 3
    elif i == 3:
        GPIO.output(23,GPIO.LOW)
        GPIO.output(25,GPIO.LOW)
        GPIO.output(9,GPIO.LOW)
        time.sleep(1)
        i = 1

    


