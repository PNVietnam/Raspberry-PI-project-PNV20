import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(18,GPIO.OUT)
GPIO.setup(23,GPIO.OUT)
GPIO.setup(25,GPIO.OUT)
GPIO.setup(9,GPIO.OUT)
GPIO.setup(7,GPIO.OUT)
print "LED on"

i = 1
cout = 0

while True:
    cout =  cout + 1
    if cout == 10:
        GPIO.output(18,GPIO.HIGH)
        GPIO.output(25,GPIO.HIGH)
        GPIO.output(7,GPIO.HIGH)
        GPIO.output(23,GPIO.HIGH)
        GPIO.output(9,GPIO.HIGH)
        time.sleep(1)
        GPIO.output(18,GPIO.LOW)
        GPIO.output(25,GPIO.LOW)
        GPIO.output(7,GPIO.LOW)
        GPIO.output(23,GPIO.LOW)
        GPIO.output(9,GPIO.LOW)
        print "LED off"
        break 
    elif i == 1:
        GPIO.output(18,GPIO.HIGH)
        GPIO.output(25,GPIO.HIGH)
        GPIO.output(7,GPIO.HIGH)
        time.sleep(2)
        GPIO.output(18,GPIO.LOW)
        GPIO.output(25,GPIO.LOW)
        GPIO.output(7,GPIO.LOW)
        i = 2
    elif i == 2:
        GPIO.output(23,GPIO.HIGH)
        GPIO.output(9,GPIO.HIGH)
        time.sleep(2)
        GPIO.output(23,GPIO.LOW)
        GPIO.output(9,GPIO.LOW)
        i = 1
    
