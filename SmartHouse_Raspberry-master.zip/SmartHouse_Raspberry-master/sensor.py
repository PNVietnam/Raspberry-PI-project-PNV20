import RPi.GPIO as GPIO
import datetime
import time
GPIO.setmode(GPIO.BOARD)
IR_INPUT=40
RELAY_OUTPUT=38
GPIO.setup(IR_INPUT,GPIO.IN)
GPIO.setup(RELAY_OUTPUT,GPIO.OUT)
GPIO.setwarnings(False)
ir_flag=False
try:
	while True:
		if  GPIO.input(IR_INPUT)==0:
			ir_flag= (not ir_flag)
			GPIO.output(RELAY_OUTPUT,ir_flag)
			print("The door was opened at %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) 
				if ir_flag 
					else "The door was closed at %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
			time.sleep(.8)
except(KeyboardInterrupt):
	print("cleaning up..")
	GPIO.cleanup()


