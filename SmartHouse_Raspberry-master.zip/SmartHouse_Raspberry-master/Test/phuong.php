<!DOCTYPE html>
<html lang="en">
<head>
  <title>LEDs Controller</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<style>
	button{
		height: 100px;
		width: 100px;
	}
</style>
<body>

<div class="container">
<center>
  <h2>LEDs Controller</h2>
  <hr>
  <form method="POST">
    <button type="submit" class="btn btn-success" name="on">ON</button>
    <button type="submit" class="btn btn-danger" name="off">OFF</button>
  </form>
  <hr>
  <p> Made by Crayi Team<p/>
</center>
</div>

</body>
</html>
<?php 
	if(isset($_POST["on"])){
    	system("gpio -g mode 27 out");
        system("gpio -g write 27 1");
	sleep(2.5);
	system("gpio -g mode 17 out");
        system("gpio -g write 17 1");
	sleep(2.5);
	}else if(isset($_POST["off"])){
 	system("gpio -g mode 17 out");
        system("gpio -g write 17 0");
	sleep(2.5);
	system("gpio -g mode 27 out");
        system("gpio -g write 27 0");
	sleep(2.5);
    	}
?>


