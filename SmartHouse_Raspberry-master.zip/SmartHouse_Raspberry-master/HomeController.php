<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Smart House</title>
  </head>
  <style>
	.alert{
		color: black;
	}
	.jumbotron{
		background-color: #bee5eb;
	}
	.living-room i{
		color: #5bc0de;
	}
	.kitchen i{
		color: #5bc0de;
	}
	.bed-room i{ 
		color: #5bc0de;
	}
	button{width: 60px;}
  </style>
  <body>
    	<div class="jumbotron text-center">
	  <h1><i class="fa fa-home" style="color: red;"></i> Smart House</h1>
	  <marquee style="width:280px;" direction="right"><p>Design by <strong style="color: red;">Infinity Team</strong></p> </marquee>
	</div>
	
	<div class="container">
	  <div class="row">
	    <div class="col-sm-4">
	      <h3 class="living-room"><i class="fa fa-tv"></i> Living Room</h3>
	      <hr>
	      <div class="alert alert-success">
		<div class="row light-control">
		    <div class="col-sm-6"><h5 style="margin-top: 5px;">Lights</h5></div>
		    <div class="col-sm-6">
			<form method="POST">
			    <button type="button" class="btn btn-info" name="lvlighton">ON</button>
			    <button type="button" class="btn btn-danger" name="lvlightoff">OFF</button>
			</form>	
		    </div>
		</div>
	      </div>
	      <div class="alert alert-success">
		<div class="row light-control">
		    <div class="col-sm-6"><h5 style="margin-top: 5px;">Fans</h5></div>
		    <div class="col-sm-6">
			<form method="POST">
			    <button type="button" class="btn btn-info" name="lvfanon" disabled>ON</button>
			    <button type="button" class="btn btn-danger" name="lvfanoff" disabled>OFF</button>
			</form>		
		    </div>
		</div>
	      </div>
	    </div>
	    <div class="col-sm-4">
	      <h3 class="kitchen"><i class="fa fa-shopping-basket"></i> Kitchen</h3>
	      <hr>
	      <div class="alert alert-info">
		<div class="row light-control">
		    <div class="col-sm-6"><h5 style="margin-top: 5px;">Lights</h5></div>
		    <div class="col-sm-6">
			<form method="POST">
			    <button type="button" class="btn btn-info" name="kclighton" disabled>ON</button>
			    <button type="button" class="btn btn-danger" name="kclightoff" disabled>OFF</button>
			</form>		
		    </div>
		</div>
	      </div>
	    </div>
	    <div class="col-sm-4">
	      <h3 class="bed-room"><i class="fa fa-bed"></i> Bed Room</h3>
      	      <hr>
  	      <div class="alert alert-danger">
		<div class="row light-control">
		    <div class="col-sm-6"><h5 style="margin-top: 5px;">Lights</h5></div>
		    <div class="col-sm-6">
			<form method="POST">
			    <button type="button" class="btn btn-info" name="bdlighton" disabled>ON</button>
			    <button type="button" class="btn btn-danger" name="bdlightoff" disabled>OFF</button>
			</form>		
		    </div>
		</div>
	      </div>
	    </div>
	  </div>
    	</div>
    <?php
	if(isset($_POST["lvlighton"])){
		system("gpio -g mode 4 out"
        	system("gpio -g write 4 1");
	}else if(isset($_POST["lvlightoff"])){
		system("gpio -g mode 4 out");
        	system("gpio -g write 4 0");
	}
    ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
    

